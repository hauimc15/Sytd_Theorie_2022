package at.htl.scooter_rental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScooterRentalApplicationTests {

    @Test
    void contextLoads() {
    }

}
