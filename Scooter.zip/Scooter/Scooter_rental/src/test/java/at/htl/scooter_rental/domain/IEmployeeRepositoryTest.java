package at.htl.scooter_rental.domain;

import static org.junit.jupiter.api.Assertions.*;

class IEmployeeRepositoryTest {

}